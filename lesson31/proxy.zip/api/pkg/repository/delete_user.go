package repository

import (
	"context"
	"fmt"
	"http_service/pkg/user"
	"sync"

	"github.com/sirupsen/logrus"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
)

type DeleteMongo struct {
	sync.Mutex
	Client *mongo.Client `json:"storage"`
}

func NewDeleteMongo(client *mongo.Client) *DeleteMongo {
	return &DeleteMongo{Client: client}
}

func (d *DeleteMongo) DeleteUser(ctx context.Context, id int64) error {
	d.Lock()
	users := d.Client.Database("Users").Collection("users")
	cur, err := users.Find(ctx, bson.D{})
	if err != nil {
		logrus.Fatal(err)
	}
	defer cur.Close(context.Background())
	for cur.Next(context.Background()) {
		user := user.User{}
		err := cur.Decode(&user)
		if err != nil {
			logrus.Fatal(err)
		}
		for i, one_user_id := range user.Friends {
			if one_user_id == id {
				user.Friends = append(user.Friends[:i], user.Friends[i+1:]...)
				var updatedDocument bson.M
				filter := bson.D{{"id", user.Id}}
				update := bson.D{{"$set", bson.D{{"friends", user.Friends}}}}
				err := users.FindOneAndUpdate(ctx, filter, update).Decode(&updatedDocument)
				if err != nil {
					// ErrNoDocuments means that the filter did not match any documents in
					// the collection.
					if err == mongo.ErrNoDocuments {
						return err
					}
					logrus.Fatal(err)
				}
				fmt.Printf("updated document %v", updatedDocument)

			}
		}
	}
	res, err := users.DeleteOne(ctx, bson.D{{"id", id}})
	if err != nil {
		logrus.Fatal(err)
	}
	fmt.Printf("deleted %v documents\n", res.DeletedCount)
	d.Unlock()
	return nil
}
