package repository

import (
	"context"
	"fmt"
	"http_service/pkg/user"
	"log"
	"sync"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
)

type UpdateMongo struct {
	sync.Mutex
	Client *mongo.Client `json:"storage"`
}

func NewUpdateMongo(client *mongo.Client) *UpdateMongo {
	return &UpdateMongo{Client: client}
}

func (u *UpdateMongo) UpdateUser(ctx context.Context, user *user.User) error {
	u.Lock()
	users := u.Client.Database("Users").Collection("users")
	var updatedDocument bson.M
	filter := bson.D{{"id", user.Id}}
	update := bson.D{{"$set", bson.D{{"name", user.Name}, {"age", user.Age}, {"friends", user.Friends}}}}
	err := users.FindOneAndUpdate(ctx, filter, update).Decode(&updatedDocument)
	if err != nil {
		// ErrNoDocuments means that the filter did not match any documents in
		// the collection.
		if err == mongo.ErrNoDocuments {
			return err
		}
		log.Fatal(err)
	}
	fmt.Printf("updated document %v", updatedDocument)
	u.Unlock()
	return nil
}
