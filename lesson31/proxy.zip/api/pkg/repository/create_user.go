package repository

import (
	"context"
	"fmt"
	"http_service/pkg/user"
	"sync"

	"github.com/sirupsen/logrus"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
)

type CreateMongo struct {
	sync.Mutex
	Client *mongo.Client `json:"storage"`
}
type idGenerator struct {
	key string `json:"key"`
	N   int64  `bson:"id"`
}

func NewCreateMongo(client *mongo.Client) *CreateMongo {
	return &CreateMongo{Client: client}
}

func (c *CreateMongo) CreateUser(ctx context.Context, u *user.User) error {
	newid, err := getNextIdUser(ctx, c.Client, "counter")
	if err != nil {
		logrus.Fatal(err)
	}
	users := c.Client.Database("Users").Collection("users")
	res, err := users.InsertOne(ctx, bson.D{primitive.E{Key: "id", Value: newid}, primitive.E{Key: "name", Value: u.Name}, primitive.E{Key: "age", Value: u.Age}, primitive.E{Key: "friends", Value: u.Friends}})
	if err != nil {
		return err
	}
	fmt.Printf("inserted document with ID %v\n", res.InsertedID)
	return nil
}

func getNextIdUser(ctx context.Context, client *mongo.Client, key string) (int64, error) {
	counter := client.Database("Users").Collection("counter")
	//var result bson.M
	r := &idGenerator{}
	filter := bson.D{{"counter", key}}
	update := bson.D{{"$inc", bson.D{{"id", 1}}}}
	err := counter.FindOneAndUpdate(ctx, filter, update).Decode(&r)
	if err != nil {
		// ErrNoDocuments means that the filter did not match any documents in
		// the collection.
		if err == mongo.ErrNoDocuments {
			_, err := counter.InsertOne(ctx, bson.M{"counter": "counter", "id": 1})
			if err != nil {
				return -1, err
			}
			return 1, nil
		} else if err != nil {
			return -1, err

		}
	}
	fmt.Printf("updated document %v", r)
	return r.N, nil
}
