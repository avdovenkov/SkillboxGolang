package repository

import (
	"context"
	"http_service/pkg/user"
	"sync"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
)

type FriendsList struct {
	Friends []*user.Friend `json:"friends"`
}

type GetUserFriendMongo struct {
	sync.Mutex
	Client *mongo.Client `json:"storage"`
}

func NewGetUserFriendMongo(client *mongo.Client) *GetUserFriendMongo {
	return &GetUserFriendMongo{Client: client}
}

func (g *GetUserFriendMongo) GetUserFriend(ctx context.Context, id int64) ([]*user.Friend, error) {
	users := g.Client.Database("Users").Collection("users")
	u := user.User{}
	friends := FriendsList{}
	err := users.FindOne(ctx, bson.D{{"id", id}}).Decode(&u)
	for _, friendid := range u.Friends {
		one_friend := user.Friend{}
		err = users.FindOne(ctx, bson.D{{"id", friendid}}).Decode(&one_friend)
		if err != nil {
			return nil, err
		}
		friends.Friends = append(friends.Friends, &one_friend)
	}
	if err != nil {
		return nil, err
	}
	return friends.Friends, nil
}
