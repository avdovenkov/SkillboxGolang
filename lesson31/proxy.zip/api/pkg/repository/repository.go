package repository

import (
	"context"
	"http_service/pkg/user"

	"go.mongodb.org/mongo-driver/mongo"
)

type CreateUser interface {
	CreateUser(context.Context, *user.User) error
}
type UpdateUser interface {
	UpdateUser(context.Context, *user.User) error
}
type DeleteUser interface {
	DeleteUser(context.Context, int64) error
}
type GetUserFriend interface {
	GetUserFriend(context.Context, int64) ([]*user.Friend, error)
}
type GetUser interface {
	GetUser(context.Context, int64) (*user.User, error)
}

type Repository struct {
	CreateUser
	UpdateUser
	DeleteUser
	GetUserFriend
	GetUser
}

func NewRepository(client *mongo.Client) *Repository {
	return &Repository{
		CreateUser:    NewCreateMongo(client),
		UpdateUser:    NewUpdateMongo(client),
		DeleteUser:    NewDeleteMongo(client),
		GetUserFriend: NewGetUserFriendMongo(client),
		GetUser:       NewGetUserMongo(client)}
}
