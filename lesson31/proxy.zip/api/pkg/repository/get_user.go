package repository

import (
	"context"
	"http_service/pkg/user"
	"sync"

	"github.com/sirupsen/logrus"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
)

type GetUserMongo struct {
	sync.Mutex
	Client *mongo.Client `json:"storage"`
}

func NewGetUserMongo(client *mongo.Client) *GetUserMongo {
	return &GetUserMongo{Client: client}
}

func (g *GetUserMongo) GetUser(ctx context.Context, id int64) (*user.User, error) {
	users := g.Client.Database("Users").Collection("users")
	user := user.User{}
	err := users.FindOne(ctx, bson.D{{"id", id}}).Decode(&user)
	if err != nil {
		logrus.Error(err)
		return nil, err
	}
	return &user, nil
}
