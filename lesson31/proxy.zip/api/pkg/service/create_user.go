package service

import (
	"context"
	"http_service/pkg/repository"
	"http_service/pkg/user"
)

type CreateService struct {
	repo repository.CreateUser
}

func NewCreateService(repo repository.CreateUser) *CreateService {
	return &CreateService{repo: repo}
}
func (c *CreateService) CreateUser(ctx context.Context, user *user.User) error {
	return c.repo.CreateUser(ctx, user)

}
