package service

import (
	"context"
	"http_service/pkg/repository"
	"http_service/pkg/user"
)

type UpdateService struct {
	repo repository.UpdateUser
}

func NewUpdateService(repo repository.UpdateUser) *UpdateService {
	return &UpdateService{repo: repo}
}
func (c *UpdateService) UpdateUser(ctx context.Context, user *user.User) error {
	return c.repo.UpdateUser(ctx, user)

}
