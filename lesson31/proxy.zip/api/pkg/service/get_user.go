package service

import (
	"context"
	"http_service/pkg/repository"
	"http_service/pkg/user"
)

type GetService struct {
	repo repository.GetUser
}

func NewGetService(repo repository.GetUser) *GetService {
	return &GetService{repo: repo}
}
func (c *GetService) GetUser(ctx context.Context, id int64) (*user.User, error) {
	return c.repo.GetUser(ctx, id)

}
