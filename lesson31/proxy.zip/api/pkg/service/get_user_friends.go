package service

import (
	"context"
	"http_service/pkg/repository"
	"http_service/pkg/user"
)

type GetUserFriendsService struct {
	repo repository.GetUserFriend
}

func NewGetUserFriendsService(repo repository.GetUserFriend) *GetUserFriendsService {
	return &GetUserFriendsService{repo: repo}
}
func (c *GetUserFriendsService) GetUserFriend(ctx context.Context, id int64) ([]*user.Friend, error) {
	return c.repo.GetUserFriend(ctx, id)

}
