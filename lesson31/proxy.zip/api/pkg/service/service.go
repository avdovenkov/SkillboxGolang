package service

import (
	"context"
	"http_service/pkg/repository"
	"http_service/pkg/user"
)

type CreateUser interface {
	CreateUser(context.Context, *user.User) error
}
type UpdateUser interface {
	UpdateUser(context.Context, *user.User) error
}
type DeleteUser interface {
	DeleteUser(context.Context, int64) error
}
type GetUserFriend interface {
	GetUserFriend(context.Context, int64) ([]*user.Friend, error)
}
type GetUser interface {
	GetUser(context.Context, int64) (*user.User, error)
}

type Service struct {
	CreateUser
	UpdateUser
	DeleteUser
	GetUserFriend
	GetUser
}

func NewService(repo *repository.Repository) *Service {
	return &Service{
		CreateUser:    NewCreateService(repo.CreateUser),
		UpdateUser:    NewUpdateService(repo.UpdateUser),
		GetUser:       NewGetService(repo.GetUser),
		GetUserFriend: NewGetUserFriendsService(repo.GetUserFriend),
		DeleteUser:    NewDeleteService(repo.DeleteUser)}
}
