package service

import (
	"context"
	"http_service/pkg/repository"
)

type DeleteService struct {
	repo repository.DeleteUser
}

func NewDeleteService(repo repository.DeleteUser) *DeleteService {
	return &DeleteService{repo: repo}
}
func (c *DeleteService) DeleteUser(ctx context.Context, id int64) error {
	return c.repo.DeleteUser(ctx, id)

}
